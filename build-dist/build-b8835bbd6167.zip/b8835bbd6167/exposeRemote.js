
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_quill_bundle = "/bundles/pimcorequill/studio/build/b8835bbd6167/static/js/remoteEntry.js"

      
    