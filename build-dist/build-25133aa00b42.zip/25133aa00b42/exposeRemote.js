
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_quill_bundle = "/bundles/pimcorequill/studio/build/25133aa00b42/static/js/remoteEntry.js"

      
    