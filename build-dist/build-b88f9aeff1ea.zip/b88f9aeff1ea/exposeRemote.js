
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_quill_bundle = "/bundles/pimcorequill/studio/build/b88f9aeff1ea/static/js/remoteEntry.js"

      
    