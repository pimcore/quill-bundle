
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_quill_bundle = "/bundles/pimcorequill/studio/build/405e26c0eb76/static/js/remoteEntry.js"

      
    