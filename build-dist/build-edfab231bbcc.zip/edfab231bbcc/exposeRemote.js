
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_quill_bundle = "/bundles/pimcorequill/studio/build/edfab231bbcc/static/js/remoteEntry.js"

      
    